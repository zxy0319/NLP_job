# B 成员大模型情感分类

B 负责中文情感二分类的大模型流水线、Zero-shot 与 Few-shot 对比，以及 Token、费用和延迟统计。新增代码位于 `src/llm/`，复用成员 C 的 `src/eval/metrics.py`，不修改 A 的数据或现有基线代码。

**当前交付状态：代码和离线测试已完成，真实模型实验待运行。** 当前没有 API 账号和 Key，未生成真实的 `preds_llm*.jsonl`、模型准确率或实验费用。单元测试里的本机 HTTP 服务只验证接口协议，测试样本和结果存放在临时目录，不属于课程实验。

## 文件与职责

| 文件 | 用途 |
| --- | --- |
| `src/llm/client.py` | 环境变量读取 Key，Chat Completions 调用，超时、重试、逐次 Token 和延迟统计 |
| `src/llm/prompt_templates.py` | Zero-shot/Few-shot 提示、开发集示例抽样、输出标签解析 |
| `src/llm/run_llm.py` | 命令行、批量实验、开发集选方案、预测输出、断点续跑、日志及报告 |
| `src/llm/__init__.py` | Python 包入口 |
| `tests/test_llm.py` | 离线回归测试和本机 HTTP 接口集成测试 |
| `B提交清单.txt` | 上交文件、剩余实验和 GitHub 合并操作 |
| `outputs/llm_input_check.json` | 真实数据的离线校验记录，不是预测结果 |

## 环境要求

Python 3.10 或更新版本。B 模块仅使用 Python 标准库，不需要增加 `requirements.txt` 依赖。原有 baseline 和 C 的可视化仍需要项目 `requirements.txt` 中的包。

所有命令在项目根目录执行。先验证不依赖账号的部分：

```bash
python -m unittest discover -s tests -v
python -m src.llm.run_llm --preview
python -m src.llm.run_llm --help
```

`--preview` 只读取开发集和测试集，检查字段、数据隔离及 SHA256，输出调用规模到 `outputs/llm_input_check.json`，并写明本次 API 调用为 0。默认从开发集抽 3 条示例，另外取 100 条验证，两种方案各运行 100 条验证和 992 条测试，共计划 **2,184 次逻辑调用**；实际重试可能增加调用量。使用 `--dev-limit 0` 则比较全部剩余开发样本。

## 配置 API

使用支持 Chat Completions 的兼容服务。以下地址和模型名是占位符，必须替换为账号实际支持的配置。程序通过 `LLM_API_KEY`（优先）或 `OPENAI_API_KEY` 读取 Key；通过 `LLM_BASE_URL` 或 `OPENAI_BASE_URL` 读取地址，通过 `LLM_MODEL` 读取模型名。程序不自动读取 `.env`。

PowerShell 配置，推荐隐藏输入 Key：

```powershell
$secureKey = Read-Host '输入你的 API Key' -AsSecureString
$env:LLM_API_KEY = [System.Net.NetworkCredential]::new('', $secureKey).Password
$env:LLM_BASE_URL = 'https://你的服务商域名/v1'
$env:LLM_MODEL = '你的实际模型名'
python -m src.llm.run_llm --strategy compare
```

Linux 或 macOS 的 Bash 配置：

```bash
read -r -s -p 'API Key: ' LLM_API_KEY
echo
export LLM_API_KEY
export LLM_BASE_URL='https://你的服务商域名/v1'
export LLM_MODEL='你的实际模型名'
python -m src.llm.run_llm --strategy compare
```

地址可填写含 `/v1` 的根地址，也可填写完整 `/chat/completions` 地址；远程服务必须使用 HTTPS。接口按 [Chat Completions 官方参考](https://developers.openai.com/api/reference/resources/chat) 的 `model/messages/temperature/max_tokens` 和 `usage.prompt_tokens/completion_tokens` 结构实现。不同厂商及模型的参数支持需要按其文档确认；优先选可直接返回标签的非推理模型。需要更长输出时用 `--max-tokens` 调整；只有服务商支持时才启用 `--send-seed`。

要完成课程的费用报告，运行时同时传入服务商公布的每百万输入和输出 Token 单价及币种。下面两项为你需要填写的数值变量，不能直接使用占位符运行：

```powershell
$inputPrice = Read-Host '每百万输入 Token 单价'
$outputPrice = Read-Host '每百万输出 Token 单价'
python -m src.llm.run_llm --strategy compare --input-price $inputPrice --output-price $outputPrice --currency CNY
```

```bash
read -r -p '每百万输入 Token 单价: ' input_price
read -r -p '每百万输出 Token 单价: ' output_price
python -m src.llm.run_llm --strategy compare --input-price "$input_price" --output-price "$output_price" --currency USD
```

单价属于各账号和模型配置，不在代码中猜测或固定。费用公式为 `(输入 Token × 输入单价 + 输出 Token × 输出单价) / 1,000,000`。程序不计算缓存折扣、免费额度、税费等，最终以账单为准。不填单价会显示费用未知，不能将其作为完整成本实验交差。

## 实验方法

固定 Python 抽样种子为 42，温度默认为 0。Few-shot 从开发集抽取 3 条示例，至少包含一条正面和一条负面；开发集验证排除示例及同文记录。API 请求中只有评论文本和 Few-shot 示例；待预测样本的真实标签只在本地评测时使用。

两种方案使用相同开发验证样本和测试样本，提示方式为对比变量。先按开发集 Macro-F1 选主方案；同分比较 Accuracy，再同分选提示更短的 Zero-shot。选定后才运行测试集，两种测试结果都报告。任务文档说“将表现更好的作为主方案”，这里明确按开发集表现选择，避免利用测试标签选提示。不要根据测试集指标反复调整模板。

程序检查 dev/test 文本重复，发现重复会停止并要求数据负责人检查，不会自行修改冻结数据。默认数据为 `data/processed/dev.jsonl` 和 `data/processed/test.jsonl`；路径相对源文件所在项目解析，不依赖启动目录。

## 实验输出

真实 API 全部运行成功后生成：

| 文件 | 上交用途 |
| --- | --- |
| `outputs/preds_llm_zeroshot.jsonl` | Zero-shot 测试集预测 |
| `outputs/preds_llm_fewshot.jsonl` | Few-shot 测试集预测 |
| `outputs/preds_llm.jsonl` | 在开发集上选定的主方案预测，交给成员 C 评测 |
| `outputs/llm_summary.json` | 配置、数据哈希、开发/测试指标、调用量、Token、估算费用、总耗时 |
| `outputs/llm_comparison.md` | 可用于报告的横向对比表与统计 |
| `logs/llm_run_YYYYMMDD.log` | 实际日期的日志，含种子、模型、单价、API 尝试、统计和错误 |

每行预测严格只有以下字段，文本及顺序与输入保持一致：

```json
{"text":"原始文本","gold_label":"positive","pred_label":"negative","latency_ms":120.5}
```

表中 `latency_ms` 是该样本逻辑请求的端到端时间，包含重试和退避；日志还记录各 HTTP 尝试的时间。Macro-F1、Accuracy、混淆矩阵复用 C 的实现。可运行 `python -m src.eval.evaluate --pred outputs/preds_llm.jsonl`，或在安装项目依赖后用 `--compare` 做整体对比。

标签解析支持纯标签、JSON 标签、明确的中文标签及带少量解释的唯一标签；两个标签同时出现、缺少标签或明显否定标签时会重试。多次失败则退出，保留断点；程序不把失败请求随意写成某一类。

## 断点与统计口径

每条完成结果即时写入 `outputs/llm_checkpoints/<指纹>/` 并刷盘；用相同命令重跑会跳过已完成样本。指纹包括模型、API 地址、参数、数据哈希、示例、验证抽样及模板版本。修改任何配置会进入新的缓存目录。需要重新测量时使用新的 `--output-dir`。

`results` 中每个实验的统计包括从缓存恢复的历史完成调用；`current_process` 仅记录当前进程新发出的 HTTP 请求，不重复算缓存，并记录所有新 HTTP 尝试的平均响应延迟 `mean_http_latency_ms`。调用量包含重试；解析失败但返回 usage 的调用也计入已知 Token。没有返回 usage 的调用标为未知，Token/成本只代表已知部分；`cost_complete=false` 表示不能宣称完整费用。失败退出时，当前进程已发生的调用记入日志，未完成的单条请求不会进入成功样本缓存；跨多次失败进程的全部费用需要结合历史日志和账单核对。

本地抽样可复现；远程服务即使温度为 0 或支持 seed，也不承诺跨服务版本的逐字确定性。报告需保留模型、时间、单价配置和日志。

## 当前可以上交的内容

当前可提交 `src/llm/`、`tests/test_llm.py`、本说明、`B提交清单.txt` 及更新的 `.gitignore`。离线检查记录和本次明确标注 preview 的日志可以作为数据检查附件，不能代替真实实验结果。

完整 B 任务仍需有账号的你或组员运行一次 `--strategy compare`，再补交上述 3 份预测文件、汇总、对比表和真实运行日志。交付压缩包保留项目相对目录，解压覆盖到同组仓库的对应路径即可；不要上传 Key、`.env`、断点缓存或 Python 缓存。
